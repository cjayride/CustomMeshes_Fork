# v0.4.1
- Added debug mode to the config
- Meshes may not be loading... we're trying to figure out why
- Updated depedency denikson-BepInExPack_Valheim-5.4.2202

# v0.4.0
- Fixed input text error when pressing F5
- Renamed config file to cjayride.CustomMeshes.cfg